<?php
/**
 * Created by PhpStorm.
 * User: truong.nq
 * Date: 1/10/2019
 * Time: 10:41 PM
 */
return [
    "data_category" =>[
        "Sản phẩm nguyên hộp",
        "Kẹo viên in hình",
        "Kẹo viên đen trắng",
        "Hoa Socola + hoa giả",
        "Khung ảnh socola"
    ]
];

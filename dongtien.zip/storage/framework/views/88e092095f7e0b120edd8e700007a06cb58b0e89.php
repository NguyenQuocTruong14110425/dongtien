<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta http-equiv="content-language" content="vi,en" />
<link href="<?php echo e(URL::asset('public/images/favicon.png')); ?>" rel="shortcut icon" type="image/x-icon">
<!-- Bootstrap core CSS -->
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
<link rel="stylesheet" href="<?php echo e(URL::asset('public/css/bootstrap.css')); ?>">
<link rel="stylesheet" href="<?php echo e(URL::asset('public/css/style_3.css')); ?>">



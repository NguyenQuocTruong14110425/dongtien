<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta http-equiv="content-language" content="vi,en" />
<link href="<?php echo e(URL::asset('public/images/favicon.png')); ?>" rel="shortcut icon" type="image/x-icon">
<!-- Bootstrap core CSS -->
<link rel="stylesheet" href="<?php echo e(URL::asset('public/css/font-awesome.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(URL::asset('public/css/bootstrap.min.css')); ?>">

<link rel="stylesheet" href="<?php echo e(URL::asset('public/css/font-ilove.css')); ?>">
<link rel="stylesheet" href="<?php echo e(URL::asset('public/css/animate.css')); ?>">
<link rel="stylesheet" href="<?php echo e(URL::asset('public/css/magnific-popup.css')); ?>">
<link rel="stylesheet" href="<?php echo e(URL::asset('public/css/owl.carousel.css')); ?>">
<link rel="stylesheet" href="<?php echo e(URL::asset('public/css/owl.theme.css')); ?>">
<link rel="stylesheet" href="<?php echo e(URL::asset('public/css/style_2.css')); ?>">



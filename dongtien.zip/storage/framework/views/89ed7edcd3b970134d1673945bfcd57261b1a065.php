<?php $__env->startSection('header-admin'); ?>
    <title>sản phẩm</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content-admin'); ?>
        <div class="pannel">
            <div class="pannel-title">
                 <div class="current-page"><?php echo app('translator')->getFromJson('component.product_create_title'); ?></div>
                    <li><a href="<?php echo e(URL::to('admin/dashboard')); ?>" title="admin/dashboad"><?php echo app('translator')->getFromJson('component.dashboard'); ?></a></li>
                    <li><a href="<?php echo e(URL::to('admin/product/')); ?>" title="admin/product"><?php echo app('translator')->getFromJson('component.product'); ?></a></li>
            </div>
            <div class="right-action">
                <button type="button" class="btn btn-dropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="fas fa-th-list"></i>
                </button>
                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                    <a class="dropdown-item" href="#"><i class="fas fa-question-circle"></i>Help</a>
                    <a class="dropdown-item" href="#"><i class="fab fa-stack-overflow"></i> Activity</a>
                </div>
            </div>
        </div>
        <?php if(Session::has('errors')): ?>
            <div class="col-sm-12">
                <?php $__currentLoopData = $errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $error; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="alert  alert-danger alert-dismissible fade show" role="alert">
                        <span class="badge badge-pill badge-danger">Lỗi</span> <?php echo e($message); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
        <?php if(Session::has('message')): ?>
            <div class="col-sm-12">
                <div class="alert  alert-success alert-dismissible fade show" role="alert">
                    <span class="badge badge-pill badge-success">Thành công</span> <?php echo e(Session::get('message')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            </div>
        <?php endif; ?>
        <form class="form-basic" action="<?php echo e(URL::to('admin/product/create')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-sm-12 col-md-8">
                <div class="card">
                    <div class="card-title">
                        <i class="fas fa-wallet"></i>
                        <h2><?php echo app('translator')->getFromJson('component.product_content'); ?></h2>
                    </div>
                    <div class="card-body">
                            <div class="form-group">
                                <label for="title"><?php echo app('translator')->getFromJson('component.product_title'); ?> *:</label>
                                <input type="text" class="form-control" id="title" name="title">
                            </div>
                            <div class="form-group">
                                <label for="description"><?php echo app('translator')->getFromJson('component.product_description'); ?>:</label>
                                <textarea type="text" rows="6" class="form-control" id="product_contents" name="product_contents"></textarea>
                                <span>ví du: mô tả về sản phẩm ( sử dụng cho sản phẩm hiện thị trên trang chủ)</span>
                            </div>
                            <div class="form-group">
                                <label for="description"><?php echo app('translator')->getFromJson('component.product_price'); ?> *:</label>
                                <input type="text" class="form-control" id="price" name="price" >
                            </div>
                            <div class="form-group">
                                <label for="description"><?php echo app('translator')->getFromJson('component.product_price_sales'); ?>:</label>
                                <input type="text" class="form-control" id="price_sales" name="price_sales">
                            </div>
                            <div class="form-group">
                                    <button type="submit" class="btn btn-info"><?php echo app('translator')->getFromJson('button.product_create'); ?></button>
                            </div>
                    </div>
                </div>
            </div>

            <div class="col-sm-12 col-md-4">
                <div class="card">
                    <div class="card-title">
                        <i class="fas fa-images"></i>
                        <h2><?php echo app('translator')->getFromJson('component.product_avatar'); ?> *</h2>
                    </div>
                    <div class="card-body">
                        <div class="image-dashboard row">
                            <div class="col-sm-12 col-md-6">
                                <input type="file" class="form-control input_upload" id="avatar" name="avatar">
                                <img class="upload-product" id="avatar_preview" onclick="uploadifle()" src="<?php echo e(URL::asset('public/images/upload.png')); ?>" width="200px" height="200px">
                            </div>
                            <div class="col-sm-12 col-md-6">
                                <p>Size: <span id="size">900 x 500 ( hệ số 1.8)</span></p>
                                <p>Type: <span id="type">png, jpg</span></p>
                                <p>Date Upload: <?php echo e(now()->format('d/m/y')); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div class="card-title">
                        <i class="fas fa-ad"></i>
                        <h2>Mở rộng</h2>
                    </div>
                    <div class="card-body">
                        <div class="form-group">
                            <label for="description"><?php echo app('translator')->getFromJson('component.product_categories'); ?> *:</label>
                            <select class="form-control" id="product_categories" name="product_categories">
                                <?php $__currentLoopData = $data_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option><?php echo e($value); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="keyword"><?php echo app('translator')->getFromJson('component.product_keyword'); ?>:</label>
                            <input type="text" class="form-control" id="keyword" name="keyword"  data-role="tagsinput"
                                   value="socola, quà tặng, 14/02, sản phẩm socola" placeholder="add item">
                        </div>
                    </div>
                </div>
            </div>

            <!-- end card form table striped -->
        </div>
        </form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script-footer'); ?>
    <script src="<?php echo e(URL::asset('public/js/pcsFormatNumber.jquery.js')); ?>"></script>
    <script>
        function uploadifle()
        {
            var avatar = document.getElementById('avatar');
            avatar.click();
        }
        $("#avatar").change(function() {
            readURL(this);
        });
        function readURL(input) {
            console.log(input)
                if (input.files && input.files[0]) {
                var reader = new FileReader();
                    console.log( input.files[0])
                    $('#type').text( input.files[0].type);
                    $('#size').text( input.files[0].size +  " KB");
                reader.onload = function(e) {
                    $('#avatar_preview').attr('src', e.target.result);
                }

                reader.readAsDataURL(input.files[0]);
            }
        }
        $('#price').pcsFormatNumber({
            decimal_separator: ",",
            to_fixed: 3,
            currency: null
        });
        $('#price_sales').pcsFormatNumber({
            decimal_separator: ",",
            to_fixed: 3,
            currency: null
        });
        $( "#price, #price_sales" ).focus(function() {
            $(this).val('');
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout_admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
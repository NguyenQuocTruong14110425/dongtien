<!doctype html>
<html lang="vi,en">
<head>
    <?php echo $__env->make('layout_admin.partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldContent('header-admin'); ?>
</head>
<body>
<section id="header">
    <div class="header-top">
        <div class="right-tt">
            <a type="buttons" class="btn btn-lang" href="<?php echo e(URL::to('language/vi')); ?>">
                <img src="<?php echo e(URL::asset('public/images/language/vietnam.jpg')); ?>"/>
                <p>Việt Nam</p>
            </a>
            <a type="buttons" class="btn btn-lang" href="<?php echo e(URL::to('language/en')); ?>">
                <img src="<?php echo e(URL::asset('public/images/language/us.png')); ?>"/>
                <p>English</p>
            </a>
            <a type="buttons" class="btn btn-lang" href="<?php echo e(URL::to('language/jp')); ?>">
                <img src="<?php echo e(URL::asset('public/images/language/japan.png')); ?>"/>
                <p>日本</p>
            </a>
        </div>
    </div>
    <div class="menu">
        <ul class="topnav">
            <li>
                <a href="#home">
                    <img src="<?php echo e(URL::asset('public/images/logo.png')); ?>">
                </a>
            </li>
            <li>
                <a href="#">
                    <i class="fas fa-file-import"></i>
                    <p>Dashboad</p>
                </a>
            </li>
            <li>
                <a href="#">
                    <i class="fas fa-file-export"></i>
                    <p>Component</p>
                </a>
            </li>
            <li>
                <a href="#">
                    <i class="fas fa-boxes"></i>
                    <p>Form, table, widgets</p>
                </a>
            </li>
            <li>
                <a href="<?php echo e(URL::to('admin/news/')); ?>" >
                    <i class="fas fa-file-signature"></i>
                    <p>Login, register</p>
                </a>
            </li>
            <li class="right-item">
                <a href="#">
                    <i class="fas fa-cog"></i>
                    <p>Setting</p>
                </a>
            </li>
            <li class="right-item">
                <a href="#">
                    <i class="fas fa-comments"></i>
                    <p>Personal infomation</p>
                </a>
            </li>
            <li class="icon">
                <a href="#" onclick="toggleMenu()">&#9776;</a>
            </li>
        </ul>
    </div>
</section>
<section id="bg-body row">
    
        
        
            
                
                
                    
                        
                        
                    
                    
                        
                            
                        
                    
                
            
        
    
    <div class="right-body col-sm-12">
    <?php echo $__env->yieldContent('content-admin'); ?>
    </div>
</section>
<?php echo $__env->make('layout_admin.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
</html>
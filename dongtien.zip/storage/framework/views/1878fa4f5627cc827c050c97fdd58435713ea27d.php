<?php $__env->startSection('header-client'); ?>
    <title>City Coin</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content-client'); ?>
    <div class="body-bg row">
        <div class="col-md-2">
            <div class="left-sidebar ">
                    <img class="big-size-kkc" src="<?php echo e(URL::asset('/public/images/valetine/khinhkhicau.png')); ?>"/>
                    <img class="small-size-kkc" src="<?php echo e(URL::asset('/public/images/valetine/khinhkhicau.png')); ?>"/>
                    <img class="may-01" src="<?php echo e(URL::asset('/public/images/valetine/may.png')); ?>"/>
                    <img class="may-02" src="<?php echo e(URL::asset('/public/images/valetine/may.png')); ?>"/>
                    <img class="hoa-01" src="<?php echo e(URL::asset('/public/images/valetine/hoa1.png')); ?>"/>
                    <img class="hoa-02" src="<?php echo e(URL::asset('/public/images/valetine/hoa1.png')); ?>"/>
            </div>
        </div>
        <div class="col-sm-12 col-md-8">
                <div class="body-main row">
                    <div class="col-sm-12 col-md-8">
                        <div class="screen-dashboard">
                            <canvas id="canvas" class="canvas-dashboard" width="600" height="460"></canvas>
                        </div>
                    </div>
                    <div class="col-sm-12 col-md-4">
                        <div class="list-item-socola">
                            <button onclick="init()" class="btn btn-success">run</button>
                            <button onclick="createShape('square')" class="btn btn-info">create element</button>
                        </div>
                    </div>
                </div>
        </div>
        <div class="col-md-2">
            <div class="right-sidebar ">
                <img class="big-size-kkc" src="<?php echo e(URL::asset('/public/images/valetine/khinhkhicau.png')); ?>"/>
                <img class="small-size-kkc" src="<?php echo e(URL::asset('/public/images/valetine/khinhkhicau.png')); ?>"/>
                <img class="may-01" src="<?php echo e(URL::asset('/public/images/valetine/may.png')); ?>"/>
                <img class="may-02" src="<?php echo e(URL::asset('/public/images/valetine/may.png')); ?>"/>
                <img class="hoa-01" src="<?php echo e(URL::asset('/public/images/valetine/hoa1.png')); ?>"/>
                <img class="hoa-02" src="<?php echo e(URL::asset('/public/images/valetine/hoa1.png')); ?>"/>
            </div>
        </div>
    </div>
    <img class="may-2" src="<?php echo e(URL::asset('/public/images/valetine/may2.png')); ?>"/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script-footer'); ?>
    <script src="<?php echo e(URL::asset('public/js/dongtien.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout_client.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('header-admin'); ?>
    <title>dashboad</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content-admin'); ?>
        <div class="pannel">
            <div class="pannel-title">
                <div class="current-page">List category post</div>
                <li><a href="<?php echo e(URL::to('admin/dashboard')); ?>" title="admin/dashboad">trang chủ</a></li>
                <li><a href="<?php echo e(URL::to('admin/product/')); ?>" title="admin/news">Danh sách sản phẩm</a></li>
            </div>
            <div class="right-action">
                <a type="buttons" href="<?php echo e(URL::to('admin/product/create')); ?>" class="btn btn-dropdown">
                    <i class="fas fa-plus"></i>
                </a>
                <button type="button" class="btn btn-dropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="fas fa-th-list"></i>
                </button>
                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                    <a class="dropdown-item" href="#"><i class="fas fa-question-circle"></i>Help</a>
                    <a class="dropdown-item" href="#"><i class="fab fa-stack-overflow"></i> Activity</a>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-title">
                        <h2>Thùng rác</h2>
                    </div>
                    <div class="card-body">
                        <div class="table-basic">
                              <div class="tab-content">
                                    <table id="trashtable" class="table table-bordered table-striped">
                                        <thead>
                                        <th><?php echo app('translator')->getFromJson('component.product_title'); ?></th>
                                        <th><?php echo app('translator')->getFromJson('component.product_description'); ?></th>
                                        <th><?php echo app('translator')->getFromJson('component.product_price'); ?></th>
                                        <th><?php echo app('translator')->getFromJson('component.product_price_sales'); ?></th>
                                        <th><?php echo app('translator')->getFromJson('component.product_categories'); ?></th>
                                        <th></th>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $product_trash; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value_trash): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($value_trash->product_title); ?></td>
                                                <td><?php echo e($value_trash->product_content); ?></td>
                                                <td><?php echo e($value_trash->product_price); ?></td>
                                                <td><?php echo e($value_trash->product_price_sales); ?></td>
                                                <td><?php echo e($value_trash->product_categories); ?></td>
                                                <td width="10%">
                                                    <a type="buttons" tages="delete" href="<?php echo e(URL::to('admin/product/delete/' . $value_trash->id)); ?>"><i class="fas fa-trash"></i></a>
                                                    <a type="buttons" tages="recover" href="<?php echo e(URL::to('admin/product/recover/' . $value_trash->id)); ?>"><i class="fas fa-reply"></i></a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end card form table striped -->
        </div>
        <script type="text/javascript">
            $( document ).ready(function() {
                var method =
                    {
                        search: true,
                        sort: true,
                        pagin: true,
                        countRow: true,
                        show: [10,25,50,100],
                        lang: 'en',
                        selectedId: false,
                        sortField :[
                            "<?php echo app('translator')->getFromJson('component.product_title'); ?>",
                            "<?php echo app('translator')->getFromJson('component.product_description'); ?>",
                            "<?php echo app('translator')->getFromJson('component.product_price'); ?>",
                            "<?php echo app('translator')->getFromJson('component.product_price_sales'); ?>",
                            "<?php echo app('translator')->getFromJson('component.product_categories'); ?>"
                        ]
                    }
                $('#trashtable').DataTableCustom(method);
            });

        </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout_admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
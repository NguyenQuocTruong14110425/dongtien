<?php $__env->startSection('header-admin'); ?>
    <title>dashboad</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content-admin'); ?>
    <div class="pannel">
        <div class="pannel-title">
            <div class="current-page"><?php echo app('translator')->getFromJson('component.users_list_title'); ?></div>
            <li><a href="<?php echo e(URL::to('admin/dashboard')); ?>" title="admin/dashboad"><?php echo app('translator')->getFromJson('component.dashboard'); ?></a></li>
            <li><a href="<?php echo e(URL::to('admin/user/')); ?>" title="admin/news"><?php echo app('translator')->getFromJson('component.users'); ?></a></li>
        </div>
        <div class="right-action">
            <a type="buttons" href="javascript:void(0)" class="btn btn-dropdown" title="<?php echo app('translator')->getFromJson('button.user_create_role'); ?>"
               data-toggle="modal" data-target="#createRole">
                <i class="far fa-calendar-plus"></i>
            </a>
            <a type="buttons" href="<?php echo e(URL::to('admin/user/create')); ?>"  title="<?php echo app('translator')->getFromJson('button.create'); ?>" class="btn btn-dropdown">
                <i class="fas fa-plus"></i>
            </a>
            <a type="buttons" href="<?php echo e(URL::to('admin/user/all-trash')); ?>"  title="<?php echo app('translator')->getFromJson('button.trash'); ?>" class="btn btn-dropdown">
                <i class="fas fa-trash"></i>
            </a>
            <button type="button" class="btn btn-dropdown" title="<?php echo app('translator')->getFromJson('button.info_more'); ?>" data-toggle="dropdown"
                    aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-th-list"></i>
            </button>
            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                <a class="dropdown-item" href="#"><i class="fas fa-question-circle"></i>Help</a>
                <a class="dropdown-item" href="#"><i class="fab fa-stack-overflow"></i> Activity</a>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-12">
            <div class="card">
                <div class="card-title">
                    <ul class="nav nav-tabs">
                        <li>
                            <a class="active show" data-toggle="tab" href="#list">
                                <i class="fas fa-clipboard-list"></i><?php echo app('translator')->getFromJson('component.users_list_title'); ?></a>
                        </li>
                        <li>
                            <a data-toggle="tab" href="#trash">
                                <i class="fab fa-firstdraft"></i><?php echo app('translator')->getFromJson('component.draft'); ?></a></li>
                    </ul>
                </div>
                <div class="card-body">
                    <div class="table-basic">
                        <div class="tab-content">
                            <div id="list" class="tab-pane fade in active show">
                                <table id="listtable" class="table table-bordered table-striped">
                                    <thead>
                                    <th><?php echo app('translator')->getFromJson('component.users_full_name'); ?></th>
                                    <th>Email</th>
                                    <th><?php echo app('translator')->getFromJson('component.users_phone'); ?></th>
                                    <th><?php echo app('translator')->getFromJson('component.users_address'); ?></th>
                                    <th><?php echo app('translator')->getFromJson('component.users_auth'); ?></th>
                                    <th><?php echo app('translator')->getFromJson('component.users_username'); ?></th>
                                    <th><?php echo app('translator')->getFromJson('component.users_status'); ?></th>
                                    <th></th>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($value->full_name); ?></td>
                                            <td><?php echo e($value->email); ?></td>
                                            <td><?php echo e($value->phone); ?></td>
                                            <td><?php echo e($value->address); ?></td>
                                            <td><?php echo e($value->auth); ?></td>
                                            <td><?php echo e($value->username); ?></td>
                                            <td><?php echo e($value->status); ?></td>
                                            <td>
                                                <a type="buttons" tages="edit"  href="<?php echo e(URL::to('admin/user/update/' . $value->id)); ?>">update</a>
                                                <a type="buttons" tages="delete"  href="<?php echo e(URL::to('admin/user/trash/' . $value->id)); ?>">trash</a>
                                                <a type="buttons" tages="info"  href="<?php echo e(URL::to('admin/user/detail/' . $value->id)); ?>">detail</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <div id="trash" class="tab-pane fade">
                                <table id="trashtable" class="table table-bordered table-striped">
                                    <thead>
                                    <th><?php echo app('translator')->getFromJson('component.users_full_name'); ?></th>
                                    <th>Email</th>
                                    <th><?php echo app('translator')->getFromJson('component.users_phone'); ?></th>
                                    <th><?php echo app('translator')->getFromJson('component.users_address'); ?></th>
                                    <th><?php echo app('translator')->getFromJson('component.users_auth'); ?></th>
                                    <th><?php echo app('translator')->getFromJson('component.users_username'); ?></th>
                                    <th><?php echo app('translator')->getFromJson('component.users_status'); ?></th>
                                    <th></th>
                                    </thead>
                                    <tbody>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- end card form table striped -->
    </div>
    <!-- create language -->
    <div id="createRole" class="modal fade" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title"><?php echo app('translator')->getFromJson('component.role_create_tile'); ?></h4>
                </div>
                <form class="form-basic" action="<?php echo e(URL::to('admin/roles/create')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="description"><?php echo app('translator')->getFromJson('component.role_name'); ?>:</label>
                            <input type="text" class="form-control" id="name" name="name"/>
                        </div>
                        <div class="form-group">
                            <label for="description"><?php echo app('translator')->getFromJson('component.role_description'); ?>:</label>
                            <input type="text" class="form-control" id="description" name="description"/>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-info"><?php echo app('translator')->getFromJson('button.role_create'); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- end card form table striped -->
    <script type="text/javascript">
        $( document ).ready(function() {
            var method =
                {
                    search: true,
                    sort: true,
                    pagin: true,
                    countRow: true,
                    show: [10,25,50,100],
                    lang: '<?php echo e(App::getLocale()); ?>',
                    selectedId: false,
                    sortField :[
                        "<?php echo app('translator')->getFromJson('component.users_full_name'); ?>",
                        "<?php echo app('translator')->getFromJson('component.users_address'); ?>",
                        "<?php echo app('translator')->getFromJson('component.users_status'); ?>",
                        "<?php echo app('translator')->getFromJson('component.users_auth'); ?>",
                        "<?php echo app('translator')->getFromJson('component.users_username'); ?>"]
                }
            $('#listtable').DataTableCustom(method);
        });

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout_admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!doctype html>
<html lang="vi,en">
<head>
    <?php echo $__env->make('layout_client.partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body>
<!--Navbar-->

    
        
            
                
                    
                
                
                    
                
            
            
            
                
                    
                    
                        
                    
                    
                        
                    
                    
                        
                    
                    
                        
                        
                            
                            
                            
                            
                            
                            
                        
                    
                    
                        
                        
                            
                            
                            
                        
                    
                    
                        
                    
                    
                        
                    
                
            
            

        
    

<div>
    <?php echo $__env->yieldContent('content-client'); ?>
</div>
<!--Footer Section-->

    
    
        
            
                
                    
                    
                        
                            
                                
                            

                            
                                
                            

                            
                                
                            

                            
                                
                            

                            
                                
                            

                            
                                
                            
                        
                    
                
            
        
    

<?php echo $__env->make('layout_client.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->yieldContent('script-footer'); ?>
</body>
</html>

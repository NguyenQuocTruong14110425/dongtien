<script src="<?php echo e(URL::asset('public/js/bootstrap-tagsinput.js')); ?>"></script>
<script src="<?php echo e(URL::asset('public/js/app.admin.js')); ?>"></script>
<script src="<?php echo e(URL::asset('public/js/datatable.js')); ?>"></script>
<script src="<?php echo e(asset('public/ckeditor/ckeditor.js')); ?>"></script>

<script  type="text/javascript">
    if($('#contents').length > 0)
    {
        CKEDITOR.replace( 'contents', {
            filebrowserBrowseUrl: '<?php echo e(asset('public/ckfinder/ckfinder.html')); ?>',
            filebrowserImageBrowseUrl: '<?php echo e(asset('public/ckfinder/ckfinder.html?type=Images')); ?>',
            filebrowserFlashBrowseUrl: '<?php echo e(asset('public/ckfinder/ckfinder.html?type=Flash')); ?>',
            filebrowserUploadUrl: '<?php echo e(asset('public/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files')); ?>',
            filebrowserImageUploadUrl: '<?php echo e(asset('public/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Images')); ?>',
            filebrowserFlashUploadUrl: '<?php echo e(asset('public/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Flash')); ?>'
        } );
    }
</script>

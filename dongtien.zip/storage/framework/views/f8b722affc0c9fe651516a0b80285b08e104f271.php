




<script src="<?php echo e(URL::asset('public/js/jquery-3.2.1.slim.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('public/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('public/js/bootstrap.min.js')); ?>"></script>

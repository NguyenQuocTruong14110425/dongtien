<script src="<?php echo e(URL::asset('public/js/jquery-3.2.1.slim.min.js')); ?>" ></script>
<script src="<?php echo e(URL::asset('public/js/jquery.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(URL::asset('public/js/bootstrap.js')); ?>"></script>
<script src="<?php echo e(URL::asset('public/js/jquery.magnific-popup.min.js')); ?>"></script>





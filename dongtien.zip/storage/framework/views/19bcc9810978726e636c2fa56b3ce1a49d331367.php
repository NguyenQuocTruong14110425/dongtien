<?php $__env->startSection('header-admin'); ?>
    <title>dashboad</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content-admin'); ?>
        <div class="pannel">
            <div class="pannel-title">
                <div class="current-page"><?php echo app('translator')->getFromJson('component.product_list'); ?></div>
                <li><a href="<?php echo e(URL::to('admin/dashboard')); ?>" title="admin/dashboad"><?php echo app('translator')->getFromJson('component.dashboard'); ?></a></li>
                <li><a href="<?php echo e(URL::to('admin/product/')); ?>" title="admin/news"><?php echo app('translator')->getFromJson('component.product_list'); ?></a></li>
            </div>
            <div class="right-action">
                <a type="buttons" href="<?php echo e(URL::to('admin/product/create')); ?>" class="btn btn-dropdown">
                    <i class="fas fa-plus"></i>
                </a>
                <a type="buttons" href="<?php echo e(URL::to('admin/product/all-trash')); ?>" class="btn btn-dropdown">
                    <i class="fas fa-trash"></i>
                </a>
                <button type="button" class="btn btn-dropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="fas fa-th-list"></i>
                </button>
                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                    <a class="dropdown-item" href="#"><i class="fas fa-question-circle"></i>Help</a>
                    <a class="dropdown-item" href="#"><i class="fab fa-stack-overflow"></i> Activity</a>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-title">
                        <ul class="nav nav-tabs">
                            <li>
                                <a class="active show" data-toggle="tab" href="#list">
                                    <i class="fas fa-clipboard-list"></i><?php echo app('translator')->getFromJson('component.product_list'); ?></a>
                            </li>
                            <li>
                                <a data-toggle="tab" href="#trash">
                                    <i class="fab fa-firstdraft"></i><?php echo app('translator')->getFromJson('component.draft'); ?></a></li>
                        </ul>
                    </div>
                    <div class="card-body">
                        <div class="table-basic">
                              <div class="tab-content">
                                <div id="list" class="tab-pane fade in active show">
                                    <table id="listtable" class="table table-bordered table-striped">
                                        <thead>
                                        <th><?php echo app('translator')->getFromJson('component.product_title'); ?></th>
                                        <th><?php echo app('translator')->getFromJson('component.product_description'); ?></th>
                                        <th><?php echo app('translator')->getFromJson('component.product_price'); ?></th>
                                        <th><?php echo app('translator')->getFromJson('component.product_price_sales'); ?></th>
                                        <th><?php echo app('translator')->getFromJson('component.product_categories'); ?></th>
                                        <th></th>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($value->product_title); ?></td>
                                                <td><?php echo e($value->product_content); ?></td>
                                                <td><?php echo e($value->product_price); ?></td>
                                                <td><?php echo e($value->product_price_sales); ?></td>
                                                <td><?php echo e($value->product_categories); ?></td>
                                                <td>
                                                    <a type="buttons" tages="edit"  href="<?php echo e(URL::to('admin/product/update/' . $value->id)); ?>">update</a>
                                                    <a type="buttons" tages="delete"  href="<?php echo e(URL::to('admin/product/trash/' . $value->id)); ?>">trash</a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                                <div id="trash" class="tab-pane fade">
                                    <table id="trashtable" class="table table-bordered table-striped">
                                        <thead>
                                        <th><?php echo app('translator')->getFromJson('component.product_title'); ?></th>
                                        <th><?php echo app('translator')->getFromJson('component.product_description'); ?></th>
                                        <th><?php echo app('translator')->getFromJson('component.product_price'); ?></th>
                                        <th><?php echo app('translator')->getFromJson('component.product_price_sales'); ?></th>
                                        <th><?php echo app('translator')->getFromJson('component.product_categories'); ?></th>
                                        <th></th>
                                        </thead>
                                        <tbody>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end card form table striped -->
        </div>
        <script type="text/javascript">
            $( document ).ready(function() {
                var method =
                    {
                        search: true,
                        sort: true,
                        pagin: true,
                        countRow: true,
                        show: [10,25,50,100],
                        lang: '<?php echo e(App::getLocale()); ?>',
                        selectedId: false,
                        sortField :[
                            "<?php echo app('translator')->getFromJson('component.product_title'); ?>",
                            "<?php echo app('translator')->getFromJson('component.product_description'); ?>",
                            "<?php echo app('translator')->getFromJson('component.product_price'); ?>",
                            "<?php echo app('translator')->getFromJson('component.product_price_sales'); ?>",
                            "<?php echo app('translator')->getFromJson('component.product_categories'); ?>"
                        ]
                    }
                $('#listtable').DataTableCustom(method);
            });

        </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout_admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
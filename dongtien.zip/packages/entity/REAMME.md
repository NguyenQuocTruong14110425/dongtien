/************************************************************************************
Khởi tạo lớp entity model
+ Tạo ra một lớp trung gian connect với database: với mỗi phương thức kết nối với database khác nhau chúng ta cần tạo 1 lớp: respository và một entity
+ validation: là lớp validate dữ liệu khi lưu xuống database
+ model: là lớp chứa các entity model
+ repository: là phương thức kết nối, thao tác với cơ sở dữ liệu
************************************************************************************?
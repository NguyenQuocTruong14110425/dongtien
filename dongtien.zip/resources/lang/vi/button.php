<?php

return [
    'create' => 'Tạo mới',
    'trash' => 'Thùng rác',
    'info_more' => 'Thông tin thêm',

    //news - tin tức
    'news_create'=> 'Thêm mới bài đăng',
    'news_update'=> 'Cập nhật bài viết',
    // news categories - danh mục tin tức
    'categories_news_create'=> 'Thêm mới danh mục tin tức',
    'categories_news_update'=> 'Cập nhật danh mục tin tức',

    //languages - ngôn ngữ
    'languages_create'=> 'Thêm ngôn ngữ',
    'languages_update'=> 'Cập nhật ngôn ngữ',
    //user - người dùng
    'user_create_role' => 'Tạo mới nhóm quyền',
    //role - phân quyền
    'role_create' => 'Tạo mới quyền',

];

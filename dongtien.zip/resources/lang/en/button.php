<?php

return [
    'create' => 'Create',
    'trash' => 'Trash',
    'info_more' => 'More infomation',
    // news - tin tức
    'news_create'=> 'Create new post',
    'news_update'=> 'Update post',

    // news categories - danh mục tin tức
    'categories_news_create'=> 'Create news category',
    'categories_news_update'=> 'Update category',

    //languages - ngôn ngữ
    'languages_create'=> 'Create new languages',
    'languages_update'=> 'Update languages',
    //user - người dùng
    'user_create_role' => 'Create new role',
    //role - phân quyền
    'role_create' => 'Create news role',

];

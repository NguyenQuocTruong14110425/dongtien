<script src="{{URL::asset('public/js/jquery-3.2.1.slim.min.js')}}" ></script>
<script src="{{URL::asset('public/js/jquery.min.js')}}" type="text/javascript"></script>
<script src="{{URL::asset('public/js/bootstrap.js')}}"></script>
<script src="{{URL::asset('public/js/jquery.magnific-popup.min.js')}}"></script>
<script src="{{URL::asset('public/js/TweenLite.js')}}"></script>
<script src="{{URL::asset('public/js/TweenMax.min.js')}}"></script>
<script src="{{URL::asset('public/js/TimelineLite.js')}}"></script>
<script src="{{URL::asset('public/js/TimelineMax.js')}}"></script>
{{--<script src="{{URL::asset('public/js/jquery-3.2.1.slim.min.js')}}"></script>--}}
{{--<script src="{{URL::asset('public/js/jquery.min.js')}}"></script>--}}
{{--<script src="{{URL::asset('public/js/bootstrap.min.js')}}"></script>--}}

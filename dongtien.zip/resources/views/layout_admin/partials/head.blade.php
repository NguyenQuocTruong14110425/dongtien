<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta http-equiv="content-language" content="vi,en" />
<link href="{{URL::asset('public/images/logo.png')}}" rel="shortcut icon" type="image/x-icon">
<!-- Bootstrap core CSS -->
<link rel="stylesheet" href="{{URL::asset('public/css/bootstrap.css')}}">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css" integrity="sha384-lKuwvrZot6UHsBSfcMvOkWwlCMgc0TaWr+30HWe3a4ltaBwTZhyTEggF5tJv8tbt" crossorigin="anonymous">

<!-- Custom styles for this template -->
<link href="{!! asset('public/css/style.admin.css') !!}" media="all" rel="stylesheet" type="text/css" />
<script src="{{URL::asset('public/js/jquery-3.2.1.slim.min.js')}}" ></script>
<script src="{{URL::asset('public/js/popper.min.js')}}" type="text/javascript"></script>
<script src="{{URL::asset('public/js/jquery.min.js')}}" type="text/javascript"></script>
<script src="{{URL::asset('public/js/bootstrap.js')}}"></script>
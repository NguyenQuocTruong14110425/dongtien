@extends('layout_client.layout')
@section('header-client')
    <title>City Coin</title>
@endsection
@section('content-client')
<div class="container">
    <button id="topup-icon" class="display-obj">
        <i class="fas fa-angle-up"></i>
    </button>
    <section id="header">
        <div class="top-header row">
            <div class="logo col-sm-12 col-md-6">
                <img src="{{URL::asset('/public/images/logo-01.png')}}">
            </div>
            <div class="social col-sm-12 col-md-6">
                <ul>
                    <li>
                        <a href="#"><i class="fab fa-facebook-f"></i></a>
                    </li>
                    <li>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                    </li>
                    <li>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                    </li>
                    <li>
                        <a href="#"><i class="fab fa-pinterest-p"></i></a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="image-avater">
            <img src="{{URL::asset('/public/images/background-top.png')}}">
        </div>
    </section>
    <section id="body-bg">
        <div class="qc-tt">
            <h3>Liên hệ để đặt hàng ngay 037.2136.156</h3>
        </div>
        <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
                <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
            </ol>
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img class="d-block w-100" src="{{URL::asset('/public/images/picture_01.jpg')}}" alt="First slide">
                </div>
                <div class="carousel-item">
                    <img class="d-block w-100" src="{{URL::asset('/public/images/picture_02.jpg')}}" alt="Second slide">
                </div>
                <div class="carousel-item">
                    <img class="d-block w-100" src="{{URL::asset('/public/images/picture_03.jpg')}}" alt="Third slide">
                </div>
            </div>
            <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>
        <div class="bar-04">
            <div class="content">
                <h3>Sản phẩm mới</h3>
            </div>
            <img src="{{URL::asset('/public/images/bar_04.jpg')}}"/>
        </div>
        <div class="video-viral row">
            <div class="left-video col-sm-12 col-md-6">
                <video controls autoplay muted>
                    <source src="{{URL::asset('/public/video/demo1.mp4')}}" type="video/mp4">
                    Your browser does not support HTML5 video.
                </video>
            </div>
            <div class="right-video col-sm-12 col-md-6">
                <h3>Giới thiệu</h3>
                <p>Cung cấp Quà tặng Valentine tại dịch vụ quà trực tuyến Iquatang.
                    com với mẫu mã đa dạng, độc đáo và ý nghĩa. Những món quà độc đáo tạo nên sự khách biệt giúp gắn kết tình cảm của các bạn lại gần nhau hơn.
                    Hãy tham khảo những món quà tặng 14/2 ý nghĩa tại <a href="http://quatang1402.com">quatang1402.com</a> nhé.</p>
            </div>
        </div>
        <div class="product row">
            <div class="content col-sm-12 col-md-6">
                <h3>Chocolate Sweetheart</h3>
                <p>Chocolate Destiny là sản phẩm độc đáo của Salty Love với sự kết hợp truyền thống của bộ đôi hoa hồng lung linh
                    và socola ngọt ngào đặt trong chiếc hộp hình tim xinh xắn, rực rỡ kèm theo những lời nhắn nhủ đầy tình cảm "
                    Just For You" sẽ khiến người ấy tan chảy trước sự ngọt ngào và lãng mạn của bạn.</p>
                <div class="button-group">
                    <a href="#" class="btn btn-price">250,000 vnđ</a>
                    <a href="#" class="btn btn-buy">Đặt hàng</a>
                </div>
            </div>
            <div class="image-product col-sm-12 col-md-6">
                <img src="{{URL::asset('/public/images/product/01.jpg')}}">
            </div>
        </div>
        <div class="product row">
            <div class="image-product col-sm-12 col-md-6">
                <img src="{{URL::asset('/public/images/product/02.jpg')}}">
            </div>
            <div class="content col-sm-12 col-md-6">
                <h3>Chocolate Sweetheart</h3>
                <p>Chocolate Destiny là sản phẩm độc đáo của Salty Love với sự kết hợp truyền thống của bộ đôi hoa hồng lung linh
                    và socola ngọt ngào đặt trong chiếc hộp hình tim xinh xắn, rực rỡ kèm theo những lời nhắn nhủ đầy tình cảm "
                    Just For You" sẽ khiến người ấy tan chảy trước sự ngọt ngào và lãng mạn của bạn.</p>
                <div class="button-group">
                    <a href="#" class="btn btn-price">1,235,000 vnđ</a>
                    <a href="#" class="btn btn-buy">Đặt hàng</a>
                </div>
            </div>
        </div>
        <div class="product row">
            <div class="content col-sm-12 col-md-6">
                <h3>Chocolate Sweetheart</h3>
                <p>Chocolate Destiny là sản phẩm độc đáo của Salty Love với sự kết hợp truyền thống của bộ đôi hoa hồng lung linh
                    và socola ngọt ngào đặt trong chiếc hộp hình tim xinh xắn, rực rỡ kèm theo những lời nhắn nhủ đầy tình cảm "
                    Just For You" sẽ khiến người ấy tan chảy trước sự ngọt ngào và lãng mạn của bạn.</p>
                <div class="button-group">
                    <a href="#" class="btn btn-price">299,000 vnđ</a>
                    <a href="#" class="btn btn-buy">Đặt hàng</a>
                </div>
            </div>
            <div class="image-product col-sm-12 col-md-6">
                <img src="{{URL::asset('/public/images/product/03.jpg')}}">
            </div>
        </div>
        <div class="product row">
            <div class="image-product col-sm-12 col-md-6">
                <img src="{{URL::asset('/public/images/product/04.jpg')}}">
            </div>
            <div class="content col-sm-12 col-md-6">
                <h3>Chocolate Sweetheart</h3>
                <p>Chocolate Destiny là sản phẩm độc đáo của Salty Love với sự kết hợp truyền thống của bộ đôi hoa hồng lung linh
                    và socola ngọt ngào đặt trong chiếc hộp hình tim xinh xắn, rực rỡ kèm theo những lời nhắn nhủ đầy tình cảm "
                    Just For You" sẽ khiến người ấy tan chảy trước sự ngọt ngào và lãng mạn của bạn.</p>
                <div class="button-group">
                    <a href="#" class="btn btn-price">500,000 vnđ</a>
                    <a href="#" class="btn btn-buy">Đặt hàng</a>
                </div>
            </div>
        </div>
        <div class="product row">
            <div class="content col-sm-12 col-md-6">
                <h3>Chocolate Sweetheart</h3>
                <p>Chocolate Destiny là sản phẩm độc đáo của Salty Love với sự kết hợp truyền thống của bộ đôi hoa hồng lung linh
                    và socola ngọt ngào đặt trong chiếc hộp hình tim xinh xắn, rực rỡ kèm theo những lời nhắn nhủ đầy tình cảm "
                    Just For You" sẽ khiến người ấy tan chảy trước sự ngọt ngào và lãng mạn của bạn.</p>
                <div class="button-group">
                    <a href="#" class="btn btn-price">170,000 vnđ</a>
                    <a href="#" class="btn btn-buy">Đặt hàng</a>
                </div>
            </div>
            <div class="image-product col-sm-12 col-md-6">
                <img src="{{URL::asset('/public/images/product/05.jpg')}}">
            </div>
        </div>
        <div class="future-new">
            <div class="future-top">
                <h3>Các chức năng nổi bật</h3>
            </div>
            <div class="future-body row">
                <div class="col-sm-12 col-md-6">
                    <a href="#">
                        <img src="{{URL::asset('/public/images/icon_1.jpg')}}">
                        <h4>Đặt hàng theo yêu cầu</h4>
                    </a>
                </div>
                <div class="col-sm-12 col-md-6">
                    <a href="#">
                        <img src="{{URL::asset('/public/images/icon_5.jpg')}}">
                        <h4>Tạo câu chuyện tình yêu</h4>
                    </a>
                </div>
                <div class="col-sm-12 col-md-6">
                    <a href="#">
                        <img src="{{URL::asset('/public/images/icon_3.jpg')}}">
                        <h4>Vòng quay valetine</h4>
                    </a>
                </div>
                <div class="col-sm-12 col-md-6">
                    <a href="#">
                        <img src="{{URL::asset('/public/images/icon_2.jpg')}}">
                        <h4>Đặt thiệp</h4>
                    </a>
                </div>
            </div>
        </div>
        <div class="body-bottom">
            <p>Valentine có lẽ là một ngày tuyệt vời đối với các cặp đôi nhưng đối với dân FA thì đó
                có lẽ sẽ là một ngày vô cùng thảm họa. Vậy làm sao để Valentine không còn là ngày tồi tệ mà lại trở thành một ngày
                cực chất cho dân FA chúng ta! Hãy tham khảo ý những kiến của Salty Love nhé!</p>
        </div>
    </section>
    <section id="footer">
        <h3>Happy Valentine!</h3>
        <div class="footer-line"></div>
        <p>Copyright © Sweet Valentine Group. All Rights Reserved.</p>
    </section>
</div>
@endsection
@section('script-footer')
    <script>
        $(document).ready(function() {
            $(window).trigger('scroll');
            $(window).bind('scroll', function () {
                var pixels = 100; //number of pixels before modifying styles
                if ($(window).scrollTop() > pixels) {
                    $('#topup-icon').css('display','block');
                } else {
                    $('#topup-icon').css('display','none');
                }
            });
            $('#topup-icon').click(function(){
                $("html, body").animate({ scrollTop: 0 }, 600);
                return false;
            });
            Zalo.init(params);
            Zalo.init({
                    version: '2.0',
                    appId: '1909228162873375583',
                    redirectUrl: 'http://quatang1402.com'
                }
            );
            // Check login status

            Zalo.getLoginStatus(function(response) {
                if (response.status === 'connected') {
                    Zalo.api('/me',
                        'GET',
                        {
                            fields: 'id,name'
                        },
                        function (response) {
                            console.log(response);
                        }
                    );
                } else {
                    Zalo.login(curentState);
                }
            });
            Zalo.login(curentState, "get_profile,get_friends,send_message,post_feed");

            Zalo.api('/me',
                'GET',
                {
                    fields: 'id, name, birthday, picture, gender'
                },
                function (response) {
                    console.log('my information: ', response);
                }
            );
        });
    </script>
    <script src="https://zjs.zdn.vn/zalo/sdk.js"></script>
@endsection
